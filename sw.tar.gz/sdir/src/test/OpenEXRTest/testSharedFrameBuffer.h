//
// SPDX-License-Identifier: BSD-3-Clause
// Copyright (c) Contributors to the OpenEXR Project.
//




#include <string>

void testSharedFrameBuffer (const std::string &tempDir);

